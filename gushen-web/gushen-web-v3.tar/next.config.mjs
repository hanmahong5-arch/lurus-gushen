/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",

  // API proxy for backend
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: process.env.API_URL
          ? `${process.env.API_URL}/:path*`
          : "http://ai-qtrd-api:8000/api/:path*",
      },
      {
        source: "/ws",
        destination: process.env.WS_URL
          ? process.env.WS_URL
          : "http://ai-qtrd-api:8000/ws",
      },
    ];
  },
};

export default nextConfig;
