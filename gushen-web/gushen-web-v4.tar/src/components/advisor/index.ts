/**
 * Advisor Components Index
 * 顾问组件索引
 */

export { AdvisorChat } from "./advisor-chat";
export { default } from "./advisor-chat";
