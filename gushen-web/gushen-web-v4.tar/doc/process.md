# GuShen Web 开发进度文档

# GuShen Web Development Progress Document

> 项目 Project: https://gushen.lurus.cn
> 更新时间 Updated: 2026-01-18

---

## 已完成功能 / Completed Features

### 2026-01-17: 前端基础架构与策略生成

**用户需求 User Request:**
- 创建 GuShen Web 前端项目
- 实现策略生成页面和 API
- 部署到 K3s 集群

**方法 Method:**
- 使用 Next.js 14 + TypeScript + Tailwind CSS
- TradingView Lightweight Charts 实现 K 线图表
- 策略生成 API 调用 lurus-api (DeepSeek)

**修改内容 Changes:**
- `src/app/page.tsx` - 营销落地页
- `src/app/dashboard/page.tsx` - 策略生成主页面
- `src/app/dashboard/trading/page.tsx` - 交易面板页面
- `src/app/api/strategy/generate/route.ts` - 策略生成 API
- `src/components/charts/kline-chart.tsx` - K 线图表组件
- `src/components/strategy-editor/` - 策略编辑器组件

**结果 Result:**
- 策略生成页面正常工作
- K 线图表显示正常
- 交易面板 UI 完成

---

### 2026-01-18: 投资顾问功能与三道六术框架

**用户需求 User Request:**
- 实现基于"三道六术"框架的投资顾问聊天功能
- 集成 lurus-api 调用 DeepSeek 进行智能分析

**方法 Method:**
- 设计三道六术投资决策框架类型定义
- 创建专业投资顾问系统提示词
- 实现投资顾问 API 端点
- 开发聊天界面组件

**新增内容 New Files:**
- `src/lib/investment-context/framework.ts` - 三道六术框架类型定义
  - 三道: 天道(宏观)、地道(行业)、人道(行为)
  - 六术: 政策术、资金术、基本术、技术术、情绪术、风控术
- `src/lib/investment-context/conversation-templates.ts` - 对话模板与系统提示词
- `src/lib/investment-context/data-sources.ts` - 数据源注册表
- `src/lib/investment-context/index.ts` - 模块导出
- `src/app/api/advisor/chat/route.ts` - 投资顾问 API 端点
- `src/components/advisor/advisor-chat.tsx` - 聊天界面组件
- `src/app/dashboard/advisor/page.tsx` - 投资顾问页面
- `src/components/ui/textarea.tsx` - 文本框 UI 组件
- `src/components/ui/badge.tsx` - 徽章 UI 组件

**修改内容 Modified Files:**
- `src/app/dashboard/page.tsx` - 添加投资顾问导航链接

**部署修复 Deployment Fixes:**
- 修复 K3s 镜像缓存问题 (使用唯一标签 v3)
- 修复 Service endpoint 配置 (添加 selector)
- 修复 IngressRoute 添加 `/api/advisor` 路由
- 修复 lurus-api URL: `http://lurus-api.lurus-system.svc.cluster.local:8850`

**结果 Result:**
- 投资顾问页面正常访问: https://gushen.lurus.cn/dashboard/advisor
- 三道六术框架展示完整
- 聊天 API 返回基于框架的专业分析
- 支持快速/标准/深度三种分析模式

---

## 进行中功能 / In Progress

### Phase 2: 认证与计费系统

**计划 Plan:**
- [ ] Stalwart OIDC 集成 (邮箱登录)
- [ ] 三层用户角色系统 (顾婶/估神/股神)
- [ ] lurus-switch 计费接口预留
- [ ] 订阅管理 UI

### Phase 3: Agent 智能系统

**计划 Plan:**
- [ ] CrewAI + LangGraph 多 Agent 框架
- [ ] 数据采集 Agent (政策/行情/舆情)
- [ ] 分析 Agent (三道六术)
- [ ] 报告生成 Agent
- [ ] 邮件推送服务

### Phase 4: Flutter 多端应用

**计划 Plan:**
- [ ] Flutter 项目初始化
- [ ] 核心功能移植 (登录/首页/对话)
- [ ] K 线图表 Flutter 实现
- [ ] Android/iOS 发布

---

## 部署信息 / Deployment Info

**域名 Domain:** gushen.lurus.cn
**命名空间 Namespace:** ai-qtrd
**节点 Node:** cloud-ubuntu-3-2c2g (worker)
**镜像 Image:** gushen-web:v3
**Service:** ai-qtrd-web:3000

**IngressRoute 路由:**
- `/` → ai-qtrd-web:3000 (前端)
- `/api/strategy` → ai-qtrd-web:3000 (策略 API)
- `/api/advisor` → ai-qtrd-web:3000 (顾问 API)

**环境变量:**
- `NEXT_PUBLIC_API_URL`: https://gushen.lurus.cn
- `LURUS_API_URL`: http://lurus-api.lurus-system.svc.cluster.local:8850
