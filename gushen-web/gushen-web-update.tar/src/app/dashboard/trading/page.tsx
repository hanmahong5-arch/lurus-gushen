"use client";

/**
 * Trading Dashboard Page with K-line Chart
 * 交易面板页面，包含K线图表
 */

import { useState } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";

// Dynamically import chart to avoid SSR issues with canvas
// 动态导入图表以避免 SSR 与 canvas 的兼容问题
const KLineChart = dynamic(
  () => import("@/components/charts/kline-chart").then((mod) => mod.KLineChart),
  {
    ssr: false,
    loading: () => (
      <div className="bg-surface rounded-xl border border-border h-[500px] flex items-center justify-center">
        <div className="text-white/50">加载图表中...</div>
      </div>
    ),
  }
);

// Mock position data
// 模拟持仓数据
const MOCK_POSITIONS = [
  {
    symbol: "BTC/USDT",
    side: "long",
    size: 0.5,
    entryPrice: 43250.00,
    currentPrice: 45120.00,
    pnl: 935.00,
    pnlPercent: 4.32,
  },
  {
    symbol: "ETH/USDT",
    side: "long",
    size: 5.0,
    entryPrice: 2280.00,
    currentPrice: 2350.00,
    pnl: 350.00,
    pnlPercent: 3.07,
  },
  {
    symbol: "SOL/USDT",
    side: "short",
    size: 50,
    entryPrice: 98.50,
    currentPrice: 95.20,
    pnl: 165.00,
    pnlPercent: 3.35,
  },
];

// Mock order data
// 模拟订单数据
const MOCK_ORDERS = [
  {
    id: "ORD001",
    symbol: "BTC/USDT",
    side: "buy",
    type: "limit",
    price: 44000.00,
    size: 0.2,
    filled: 0,
    status: "open",
    time: "2026-01-17 10:30:00",
  },
  {
    id: "ORD002",
    symbol: "ETH/USDT",
    side: "sell",
    type: "stop-loss",
    price: 2200.00,
    size: 2.5,
    filled: 0,
    status: "open",
    time: "2026-01-17 09:15:00",
  },
];

// Symbol list
// 交易对列表
const SYMBOLS = [
  { symbol: "BTC/USDT", price: 45120.00, change: 2.35 },
  { symbol: "ETH/USDT", price: 2350.00, change: 1.82 },
  { symbol: "SOL/USDT", price: 95.20, change: -1.25 },
  { symbol: "BNB/USDT", price: 312.50, change: 0.95 },
  { symbol: "XRP/USDT", price: 0.5820, change: -0.45 },
  { symbol: "ADA/USDT", price: 0.4850, change: 3.21 },
];

export default function TradingPage() {
  const [selectedSymbol, setSelectedSymbol] = useState("BTC/USDT");
  const [activeTab, setActiveTab] = useState<"positions" | "orders">("positions");

  // Calculate total PnL
  // 计算总盈亏
  const totalPnL = MOCK_POSITIONS.reduce((sum, pos) => sum + pos.pnl, 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-surface/80 backdrop-blur-xl border-b border-border">
        <div className="max-w-[1920px] mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-accent to-accent-400 flex items-center justify-center">
                <span className="text-primary-600 font-bold">G</span>
              </div>
              <span className="text-lg font-bold text-white">
                GuShen<span className="text-accent">.</span>
              </span>
            </Link>

            <nav className="flex items-center gap-6">
              <Link
                href="/dashboard"
                className="text-white/60 hover:text-white text-sm transition"
              >
                策略编辑器
              </Link>
              <Link href="/dashboard/trading" className="text-accent text-sm font-medium">
                交易面板
              </Link>
              <Link
                href="/dashboard/history"
                className="text-white/60 hover:text-white text-sm transition"
              >
                历史记录
              </Link>
            </nav>

            <div className="flex items-center gap-3">
              <span className="text-sm text-white/50">演示账户</span>
              <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                <span className="text-accent text-sm">D</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-[1920px] mx-auto p-4">
        <div className="grid grid-cols-12 gap-4">
          {/* Left sidebar - Symbol list */}
          <div className="col-span-2">
            <div className="bg-surface rounded-xl border border-border p-3">
              <h3 className="text-sm font-medium text-white mb-3">
                交易对 / Symbols
              </h3>
              <div className="space-y-1">
                {SYMBOLS.map((item) => (
                  <button
                    key={item.symbol}
                    onClick={() => setSelectedSymbol(item.symbol)}
                    className={`w-full flex items-center justify-between p-2 rounded-lg transition ${
                      selectedSymbol === item.symbol
                        ? "bg-accent/10 border border-accent/30"
                        : "hover:bg-white/5"
                    }`}
                  >
                    <span
                      className={`text-sm font-medium ${
                        selectedSymbol === item.symbol ? "text-accent" : "text-white"
                      }`}
                    >
                      {item.symbol}
                    </span>
                    <div className="text-right">
                      <div className="text-xs text-white/70">
                        {item.price.toLocaleString()}
                      </div>
                      <div
                        className={`text-xs ${
                          item.change >= 0 ? "text-profit" : "text-loss"
                        }`}
                      >
                        {item.change >= 0 ? "+" : ""}
                        {item.change}%
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Center - Chart */}
          <div className="col-span-7">
            <KLineChart
              symbol={selectedSymbol}
              height={500}
              showVolume={true}
              showMA={true}
              maWindows={[5, 20, 60]}
            />
          </div>

          {/* Right sidebar - Order entry */}
          <div className="col-span-3">
            <div className="bg-surface rounded-xl border border-border p-4">
              <h3 className="text-sm font-medium text-white mb-4">
                下单 / Place Order
              </h3>

              {/* Order type tabs */}
              <div className="flex gap-2 mb-4">
                <button className="flex-1 py-2 text-xs font-medium bg-accent/10 text-accent rounded-lg">
                  限价单
                </button>
                <button className="flex-1 py-2 text-xs font-medium text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition">
                  市价单
                </button>
                <button className="flex-1 py-2 text-xs font-medium text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition">
                  止损单
                </button>
              </div>

              {/* Price input */}
              <div className="mb-3">
                <label className="block text-xs text-white/50 mb-1">
                  价格 / Price
                </label>
                <input
                  type="number"
                  placeholder="0.00"
                  className="w-full bg-background border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent"
                />
              </div>

              {/* Size input */}
              <div className="mb-3">
                <label className="block text-xs text-white/50 mb-1">
                  数量 / Size
                </label>
                <input
                  type="number"
                  placeholder="0.00"
                  className="w-full bg-background border border-border rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-accent"
                />
              </div>

              {/* Size percentage buttons */}
              <div className="flex gap-2 mb-4">
                {[25, 50, 75, 100].map((pct) => (
                  <button
                    key={pct}
                    className="flex-1 py-1 text-xs text-white/50 hover:text-white border border-border rounded hover:border-accent/50 transition"
                  >
                    {pct}%
                  </button>
                ))}
              </div>

              {/* Buy/Sell buttons */}
              <div className="flex gap-2">
                <button className="flex-1 py-3 bg-profit hover:bg-profit/80 text-white font-medium rounded-lg transition">
                  买入 / Buy
                </button>
                <button className="flex-1 py-3 bg-loss hover:bg-loss/80 text-white font-medium rounded-lg transition">
                  卖出 / Sell
                </button>
              </div>

              {/* Account summary */}
              <div className="mt-4 pt-4 border-t border-border">
                <div className="flex justify-between text-xs mb-2">
                  <span className="text-white/50">可用余额</span>
                  <span className="text-white">$50,000.00</span>
                </div>
                <div className="flex justify-between text-xs mb-2">
                  <span className="text-white/50">持仓市值</span>
                  <span className="text-white">$35,420.00</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-white/50">总盈亏</span>
                  <span className={totalPnL >= 0 ? "text-profit" : "text-loss"}>
                    {totalPnL >= 0 ? "+" : ""}${totalPnL.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom - Positions & Orders */}
        <div className="mt-4">
          <div className="bg-surface rounded-xl border border-border">
            {/* Tabs */}
            <div className="flex border-b border-border">
              <button
                onClick={() => setActiveTab("positions")}
                className={`px-6 py-3 text-sm font-medium transition ${
                  activeTab === "positions"
                    ? "text-accent border-b-2 border-accent"
                    : "text-white/50 hover:text-white"
                }`}
              >
                持仓 / Positions ({MOCK_POSITIONS.length})
              </button>
              <button
                onClick={() => setActiveTab("orders")}
                className={`px-6 py-3 text-sm font-medium transition ${
                  activeTab === "orders"
                    ? "text-accent border-b-2 border-accent"
                    : "text-white/50 hover:text-white"
                }`}
              >
                挂单 / Orders ({MOCK_ORDERS.length})
              </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              {activeTab === "positions" ? (
                <table className="w-full">
                  <thead>
                    <tr className="text-xs text-white/50 border-b border-border">
                      <th className="text-left px-4 py-3 font-medium">交易对</th>
                      <th className="text-left px-4 py-3 font-medium">方向</th>
                      <th className="text-right px-4 py-3 font-medium">数量</th>
                      <th className="text-right px-4 py-3 font-medium">开仓价</th>
                      <th className="text-right px-4 py-3 font-medium">现价</th>
                      <th className="text-right px-4 py-3 font-medium">盈亏</th>
                      <th className="text-right px-4 py-3 font-medium">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {MOCK_POSITIONS.map((pos, index) => (
                      <tr
                        key={index}
                        className="text-sm border-b border-border/50 hover:bg-white/5"
                      >
                        <td className="px-4 py-3 text-white font-medium">
                          {pos.symbol}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-xs ${
                              pos.side === "long"
                                ? "bg-profit/20 text-profit"
                                : "bg-loss/20 text-loss"
                            }`}
                          >
                            {pos.side === "long" ? "多" : "空"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right text-white">
                          {pos.size}
                        </td>
                        <td className="px-4 py-3 text-right text-white/70">
                          {pos.entryPrice.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-right text-white">
                          {pos.currentPrice.toLocaleString()}
                        </td>
                        <td
                          className={`px-4 py-3 text-right font-medium ${
                            pos.pnl >= 0 ? "text-profit" : "text-loss"
                          }`}
                        >
                          {pos.pnl >= 0 ? "+" : ""}${pos.pnl.toFixed(2)} (
                          {pos.pnlPercent >= 0 ? "+" : ""}
                          {pos.pnlPercent}%)
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button className="px-3 py-1 text-xs text-loss border border-loss/30 rounded hover:bg-loss/10 transition">
                            平仓
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <table className="w-full">
                  <thead>
                    <tr className="text-xs text-white/50 border-b border-border">
                      <th className="text-left px-4 py-3 font-medium">订单号</th>
                      <th className="text-left px-4 py-3 font-medium">交易对</th>
                      <th className="text-left px-4 py-3 font-medium">方向</th>
                      <th className="text-left px-4 py-3 font-medium">类型</th>
                      <th className="text-right px-4 py-3 font-medium">价格</th>
                      <th className="text-right px-4 py-3 font-medium">数量</th>
                      <th className="text-right px-4 py-3 font-medium">时间</th>
                      <th className="text-right px-4 py-3 font-medium">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {MOCK_ORDERS.map((order) => (
                      <tr
                        key={order.id}
                        className="text-sm border-b border-border/50 hover:bg-white/5"
                      >
                        <td className="px-4 py-3 text-white/50 font-mono text-xs">
                          {order.id}
                        </td>
                        <td className="px-4 py-3 text-white font-medium">
                          {order.symbol}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-xs ${
                              order.side === "buy"
                                ? "bg-profit/20 text-profit"
                                : "bg-loss/20 text-loss"
                            }`}
                          >
                            {order.side === "buy" ? "买入" : "卖出"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-white/70 text-xs uppercase">
                          {order.type}
                        </td>
                        <td className="px-4 py-3 text-right text-white">
                          {order.price.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-right text-white">
                          {order.size}
                        </td>
                        <td className="px-4 py-3 text-right text-white/50 text-xs">
                          {order.time}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button className="px-3 py-1 text-xs text-loss border border-loss/30 rounded hover:bg-loss/10 transition">
                            撤单
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
