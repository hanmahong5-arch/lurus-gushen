"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-accent-400 flex items-center justify-center">
              <span className="text-primary-600 font-bold text-lg">G</span>
            </div>
            <span className="text-xl font-bold text-white">
              GuShen
              <span className="text-accent">.</span>
            </span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link
              href="/dashboard"
              className="text-white/70 hover:text-white transition"
            >
              策略编辑 / Strategy
            </Link>
            <Link
              href="/dashboard/trading"
              className="text-white/70 hover:text-white transition"
            >
              交易面板 / Trading
            </Link>
            <Link
              href="/dashboard/advisor"
              className="text-white/70 hover:text-white transition"
            >
              投资顾问 / Advisor
            </Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                登录 / Login
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button size="sm">免费试用</Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
