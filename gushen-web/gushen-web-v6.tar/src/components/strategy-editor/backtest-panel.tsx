"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface BacktestResult {
  totalReturn: number;
  annualizedReturn: number;
  maxDrawdown: number;
  sharpeRatio: number;
  winRate: number;
  totalTrades: number;
}

interface BacktestPanelProps {
  result?: BacktestResult;
  isRunning?: boolean;
  onRunBacktest: () => Promise<void>;
}

// Demo result for display
const demoResult: BacktestResult = {
  totalReturn: 23.45,
  annualizedReturn: 31.2,
  maxDrawdown: -12.8,
  sharpeRatio: 1.85,
  winRate: 65.3,
  totalTrades: 47,
};

export function BacktestPanel({
  result,
  isRunning = false,
  onRunBacktest,
}: BacktestPanelProps) {
  const [showDetails, setShowDetails] = useState(false);
  const displayResult = result || demoResult;

  // Export backtest report as JSON
  // 导出回测报告为JSON
  const handleExport = () => {
    const report = {
      generatedAt: new Date().toISOString(),
      platform: "GuShen AI Trading",
      results: displayResult,
      summary: `总收益率: ${displayResult.totalReturn}%, 年化收益: ${displayResult.annualizedReturn}%, 最大回撤: ${displayResult.maxDrawdown}%`,
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `backtest-report-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-surface/80 backdrop-blur-xl border border-border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-primary/50 border-b border-border">
        <div className="flex items-center gap-2">
          <span className="text-lg">📊</span>
          <span className="text-sm font-medium text-white">
            回测结果 / Backtest Results
          </span>
        </div>
        <Button
          size="sm"
          onClick={onRunBacktest}
          disabled={isRunning}
          className="gap-1"
        >
          {isRunning ? (
            <>
              <span className="w-3 h-3 border-2 border-primary-600/30 border-t-primary-600 rounded-full animate-spin" />
              回测中...
            </>
          ) : (
            <>
              <span>▶</span>
              运行回测
            </>
          )}
        </Button>
      </div>

      {/* Results grid */}
      <div className="p-4">
        {isRunning ? (
          <div className="py-8 flex flex-col items-center justify-center">
            <div className="w-12 h-12 border-3 border-accent/30 border-t-accent rounded-full animate-spin mb-4" />
            <span className="text-white/50">正在运行回测...</span>
            <span className="text-xs text-white/30 mt-1">这可能需要几秒钟</span>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {/* Total Return */}
            <MetricCard
              label="总收益率"
              labelEn="Total Return"
              value={`${displayResult.totalReturn >= 0 ? "+" : ""}${displayResult.totalReturn.toFixed(2)}%`}
              valueColor={
                displayResult.totalReturn >= 0 ? "text-profit" : "text-loss"
              }
              highlight
            />

            {/* Annualized Return */}
            <MetricCard
              label="年化收益"
              labelEn="Annualized"
              value={`${displayResult.annualizedReturn >= 0 ? "+" : ""}${displayResult.annualizedReturn.toFixed(1)}%`}
              valueColor={
                displayResult.annualizedReturn >= 0
                  ? "text-profit"
                  : "text-loss"
              }
            />

            {/* Max Drawdown */}
            <MetricCard
              label="最大回撤"
              labelEn="Max Drawdown"
              value={`${displayResult.maxDrawdown.toFixed(1)}%`}
              valueColor="text-loss"
            />

            {/* Sharpe Ratio */}
            <MetricCard
              label="夏普比率"
              labelEn="Sharpe Ratio"
              value={displayResult.sharpeRatio.toFixed(2)}
              valueColor={
                displayResult.sharpeRatio >= 1 ? "text-profit" : "text-white"
              }
            />

            {/* Win Rate */}
            <MetricCard
              label="胜率"
              labelEn="Win Rate"
              value={`${displayResult.winRate.toFixed(1)}%`}
              valueColor={
                displayResult.winRate >= 50 ? "text-profit" : "text-loss"
              }
            />

            {/* Total Trades */}
            <MetricCard
              label="交易次数"
              labelEn="Total Trades"
              value={displayResult.totalTrades.toString()}
              valueColor="text-white"
            />
          </div>
        )}

        {/* Details Modal */}
        {showDetails && (
          <div className="mt-4 p-4 bg-primary/30 rounded-lg border border-border">
            <h4 className="text-sm font-medium text-white mb-3">
              详细统计 / Detailed Stats
            </h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-white/50">盈利交易</span>
                <span className="text-profit">
                  {Math.round(
                    (displayResult.totalTrades * displayResult.winRate) / 100,
                  )}{" "}
                  笔
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">亏损交易</span>
                <span className="text-loss">
                  {Math.round(
                    (displayResult.totalTrades *
                      (100 - displayResult.winRate)) /
                      100,
                  )}{" "}
                  笔
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">平均持仓时间</span>
                <span className="text-white">2.3 天</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">最大单笔盈利</span>
                <span className="text-profit">+8.5%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">最大单笔亏损</span>
                <span className="text-loss">-3.2%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">盈亏比</span>
                <span className="text-white">2.65:1</span>
              </div>
            </div>
          </div>
        )}

        {/* Action buttons */}
        {!isRunning && (
          <div className="flex gap-2 mt-4 pt-4 border-t border-border">
            <Button
              variant="secondary"
              size="sm"
              className="flex-1"
              onClick={() => setShowDetails(!showDetails)}
            >
              {showDetails ? "收起详情" : "查看详情"} / Details
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
              onClick={handleExport}
            >
              导出报告 / Export
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

interface MetricCardProps {
  label: string;
  labelEn: string;
  value: string;
  valueColor?: string;
  highlight?: boolean;
}

function MetricCard({
  label,
  labelEn,
  value,
  valueColor = "text-white",
  highlight = false,
}: MetricCardProps) {
  return (
    <div
      className={cn(
        "p-3 rounded-lg",
        highlight ? "bg-accent/10 border border-accent/30" : "bg-primary/30",
      )}
    >
      <div className="text-xs text-white/50 mb-1">
        {label}
        <span className="block text-white/30">{labelEn}</span>
      </div>
      <div className={cn("text-xl font-bold", valueColor)}>{value}</div>
    </div>
  );
}
