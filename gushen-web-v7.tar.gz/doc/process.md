# GuShen Web 开发进度文档

# GuShen Web Development Progress Document

> 项目 Project: https://gushen.lurus.cn
> 更新时间 Updated: 2026-01-18

---

## 已完成功能 / Completed Features

### 2026-01-17: 前端基础架构与策略生成

**用户需求 User Request:**
- 创建 GuShen Web 前端项目
- 实现策略生成页面和 API
- 部署到 K3s 集群

**方法 Method:**
- 使用 Next.js 14 + TypeScript + Tailwind CSS
- TradingView Lightweight Charts 实现 K 线图表
- 策略生成 API 调用 lurus-api (DeepSeek)

**修改内容 Changes:**
- `src/app/page.tsx` - 营销落地页
- `src/app/dashboard/page.tsx` - 策略生成主页面
- `src/app/dashboard/trading/page.tsx` - 交易面板页面
- `src/app/api/strategy/generate/route.ts` - 策略生成 API
- `src/components/charts/kline-chart.tsx` - K 线图表组件
- `src/components/strategy-editor/` - 策略编辑器组件

**结果 Result:**
- 策略生成页面正常工作
- K 线图表显示正常
- 交易面板 UI 完成

---

### 2026-01-18: 投资顾问功能与三道六术框架

**用户需求 User Request:**
- 实现基于"三道六术"框架的投资顾问聊天功能
- 集成 lurus-api 调用 DeepSeek 进行智能分析

**方法 Method:**
- 设计三道六术投资决策框架类型定义
- 创建专业投资顾问系统提示词
- 实现投资顾问 API 端点
- 开发聊天界面组件

**新增内容 New Files:**
- `src/lib/investment-context/framework.ts` - 三道六术框架类型定义
  - 三道: 天道(宏观)、地道(行业)、人道(行为)
  - 六术: 政策术、资金术、基本术、技术术、情绪术、风控术
- `src/lib/investment-context/conversation-templates.ts` - 对话模板与系统提示词
- `src/lib/investment-context/data-sources.ts` - 数据源注册表
- `src/lib/investment-context/index.ts` - 模块导出
- `src/app/api/advisor/chat/route.ts` - 投资顾问 API 端点
- `src/components/advisor/advisor-chat.tsx` - 聊天界面组件
- `src/app/dashboard/advisor/page.tsx` - 投资顾问页面
- `src/components/ui/textarea.tsx` - 文本框 UI 组件
- `src/components/ui/badge.tsx` - 徽章 UI 组件

**修改内容 Modified Files:**
- `src/app/dashboard/page.tsx` - 添加投资顾问导航链接

**部署修复 Deployment Fixes:**
- 修复 K3s 镜像缓存问题 (使用唯一标签 v3)
- 修复 Service endpoint 配置 (添加 selector)
- 修复 IngressRoute 添加 `/api/advisor` 路由
- 修复 lurus-api URL: `http://lurus-api.lurus-system.svc.cluster.local:8850`

**结果 Result:**
- 投资顾问页面正常访问: https://gushen.lurus.cn/dashboard/advisor
- 三道六术框架展示完整
- 聊天 API 返回基于框架的专业分析
- 支持快速/标准/深度三种分析模式

---

### 2026-01-18: 按钮功能完善与部署更新

**用户需求 User Request:**
- 完善策略生成页面按钮功能
- 完善交易面板页面按钮功能
- 构建并部署更新

**方法 Method:**
- 为所有交互元素添加状态管理和事件处理
- 使用 React useState 和 useCallback 实现响应式交互
- 使用 k3s ctr 正确导入镜像 (需要 io.cri-containerd.image=managed 标签)

**修改内容 Modified Files:**

1. `src/components/strategy-editor/strategy-input.tsx`
   - AI 优化按钮: 点击后自动在策略描述末尾添加优化提示

2. `src/components/strategy-editor/backtest-panel.tsx`
   - 添加 showDetails 状态控制详细数据展示
   - 导出报告按钮: 生成 JSON 格式回测报告并下载
   - 查看详情按钮: 切换显示详细统计数据
   - 详细统计包含: 盈利/亏损交易数、平均持仓时间、最大单笔盈亏、盈亏比

3. `src/app/dashboard/trading/page.tsx`
   - 添加 Position 和 Order 类型定义
   - 添加完整状态管理: positions, orders, orderType, orderPrice, orderSize, balance, notification
   - 订单类型标签: 限价单/市价单/止损单切换，带高亮状态
   - 价格输入: 市价单时禁用并显示当前价格
   - 数量输入: 支持手动输入
   - 百分比按钮: 25%/50%/75%/100%快速设置仓位
   - 买入/卖出按钮: 执行下单逻辑（市价单立即成交，限价单加入订单簿）
   - 账户摘要: 动态显示余额和持仓市值
   - 持仓表格: 使用 positions 状态，平仓按钮触发 handleClosePosition
   - 订单表格: 使用 orders 状态，撤单按钮触发 handleCancelOrder
   - 通知提示: 交易操作后显示成功/错误提示

**部署修复 Deployment Fixes:**
- 发现 OCI image index 格式与 CRI 不兼容问题
- 使用 DOCKER_BUILDKIT=0 构建传统格式镜像
- 使用 k3s ctr images import 而非普通 ctr，确保添加 managed 标签
- 部署镜像版本: gushen-web:v5-legacy

**结果 Result:**
- 策略生成页面: AI 优化、回测、导出、查看详情按钮全部可用
- 交易面板页面: 下单、平仓、撤单功能完整
- 所有页面正常访问: dashboard(200), trading(200), advisor(200)
- 部署成功，Pod 运行正常

---

### 2026-01-18: 主页按钮跳转功能修复

**用户需求 User Request:**
- 主页上几乎所有按钮都没有跳转功能
- 需要建立清晰的用户导航流程

**方法 Method:**
- 深度分析主页所有组件的按钮和链接
- 设计用户旅程: 访客 → 体验功能 → 深度使用
- 为所有 CTA 按钮添加正确的导航链接

**修改内容 Modified Files:**

1. `src/components/landing/header.tsx`
   - 导航链接: 策略编辑、交易面板、投资顾问
   - 登录/免费试用按钮 → /dashboard

2. `src/components/landing/hero.tsx`
   - "免费体验" 按钮 → /dashboard
   - "AI顾问" 按钮 → /dashboard/advisor
   - "运行回测" 按钮 → /dashboard
   - "开始交易" 按钮 → /dashboard/trading

3. `src/components/landing/cta.tsx`
   - "立即体验" 按钮 → /dashboard
   - "咨询AI顾问" 按钮 → /dashboard/advisor

4. `src/components/landing/footer.tsx`
   - 产品链接: 策略编辑器、交易面板、AI投资顾问、开源项目
   - 支持链接: AI帮助、联系邮箱、Lurus官网、GitHub

**部署信息:**
- 镜像版本: gushen-web:v6
- 使用 k3s ctr images import 正确导入镜像

**结果 Result:**
- 主页所有按钮和链接正常跳转
- 用户可以从主页直接进入任意功能页面
- 导航逻辑清晰: 主页 ↔ 策略编辑 ↔ 交易面板 ↔ 投资顾问

---

### 2026-01-18: 用户认证系统 (NextAuth.js)

**用户需求 User Request:**
- 实现用户登录/注册功能
- 原计划使用 Stalwart OIDC，因网络配置问题改用 NextAuth.js

**方法 Method:**
- 使用 NextAuth.js v4 实现 CredentialsProvider 认证
- bcryptjs 进行密码哈希
- Session/JWT 回调支持用户角色
- 保留 Stalwart OIDC 代码供未来使用

**新增内容 New Files:**
- `src/lib/auth.ts` - NextAuth 配置，含演示用户
- `src/app/api/auth/[...nextauth]/route.ts` - NextAuth API 路由
- `src/components/providers/session-provider.tsx` - 客户端 Session Provider
- `src/app/auth/login/page.tsx` - 登录页面 (含 Suspense 修复)
- `src/app/auth/register/page.tsx` - 注册页面
- `src/app/auth/error/page.tsx` - 错误页面 (含 Suspense 修复)

**修改内容 Modified Files:**
- `src/app/layout.tsx` - 添加 AuthSessionProvider
- `src/components/landing/header.tsx` - 添加用户下拉菜单
- `package.json` - 添加 next-auth, bcryptjs 依赖

**结果 Result:**
- 登录/注册页面正常访问
- 支持演示账户: demo@gushen.lurus.cn / demo123
- 登录后 header 显示用户信息和退出按钮
- Session 包含用户角色信息

---

### 2026-01-18: 交易面板数据源系统

**用户需求 User Request:**
- 修复交易面板使用国内知名数据源API
- 自动发起调用并缓存
- 确保过程完整性和可观测性
- 确保结果可靠性和稳定性

**方法 Method:**
- 设计多数据源架构，支持自动故障转移
- 实现东方财富(EastMoney)和新浪财经(Sina)两个数据源
- 创建带TTL的LRU缓存层
- 实现结构化日志和请求指标收集
- 创建React Hooks简化前端数据获取

**新增内容 New Files:**

1. **数据服务核心 / Data Service Core:**
   - `src/lib/data-service/types.ts` - 市场数据类型定义
     - StockQuote, KLineData, IndexQuote, CapitalFlow, NorthBoundFlow
     - ApiResponse, CacheEntry, LogEntry, RequestMetrics, ServiceHealth
   - `src/lib/data-service/cache.ts` - 带TTL的LRU缓存实现
     - DataCache 泛型类
     - 专用缓存实例: quoteCache, klineCache, indexCache, capitalFlowCache
     - 缓存键生成工具函数
   - `src/lib/data-service/logger.ts` - 结构化日志和指标收集
     - DataServiceLogger 类
     - 请求追踪和健康状态监控
     - generateRequestId, createRequestTracker 工具函数

2. **数据源实现 / Data Source Implementations:**
   - `src/lib/data-service/sources/eastmoney.ts` - 东方财富API
     - getStockQuote: 获取股票行情
     - getKLineData: 获取K线数据
     - getMajorIndices: 获取主要指数
     - getCapitalFlow: 获取资金流向
     - getNorthBoundFlow: 获取北向资金
   - `src/lib/data-service/sources/sina.ts` - 新浪财经API (备用)
     - getStockQuote, getKLineData, getMajorIndices

3. **统一服务入口 / Unified Service Entry:**
   - `src/lib/data-service/index.ts` - 统一数据服务
     - 自动故障转移: 主数据源失败自动切换备用源
     - 批量获取: getBatchQuotes
     - 服务状态: getServiceStats, getServiceHealth
     - Mock数据生成器用于开发

4. **API路由 / API Routes:**
   - `src/app/api/market/quote/route.ts` - 股票行情API
   - `src/app/api/market/kline/route.ts` - K线数据API
   - `src/app/api/market/indices/route.ts` - 指数行情API
   - `src/app/api/market/flow/route.ts` - 资金流向API
   - `src/app/api/market/status/route.ts` - 服务状态API

5. **React Hooks:**
   - `src/hooks/use-market-data.ts` - 市场数据Hooks
     - useStockQuote: 获取单个股票行情
     - useKLineData: 获取K线数据
     - useMajorIndices: 获取主要指数
     - useCapitalFlow: 获取资金流向
     - useNorthBoundFlow: 获取北向资金
     - useBatchQuotes: 批量获取行情
     - useServiceStatus: 获取服务状态

6. **UI组件 / UI Components:**
   - `src/components/dashboard/data-status-panel.tsx` - 数据状态监控面板
     - 显示服务健康状态
     - 显示缓存命中率
     - 显示各数据源状态
     - 可展开/折叠

**修改内容 Modified Files:**
- `src/app/dashboard/trading/page.tsx` - 集成实时数据
  - 添加市场概览栏 (指数 + 北向资金)
  - 添加实时行情Tab
  - 集成 DataStatusPanel 组件

**架构特性 Architecture Features:**
- 多数据源自动故障转移
- 分层缓存 (行情5秒，K线按周期，资金流30秒)
- 结构化日志记录每个请求
- 请求指标收集和健康监控
- 支持USE_MOCK_DATA环境变量切换模拟数据

**结果 Result:**
- 交易面板显示实时指数数据
- 北向资金实时更新
- 数据状态面板显示服务健康状态
- 缓存有效减少API调用
- 构建验证通过

---

### 2026-01-18: 产品架构审视与历史记录页面

**用户需求 User Request:**
- 修复历史记录页面404错误
- 审视产品架构
- 统一导航结构
- 增强用户体验

**方法 Method:**
- 分析现有页面结构和导航链接
- 发现导航不一致问题:
  - dashboard页面有历史记录链接但页面不存在
  - 各页面导航项目和样式不一致
- 创建缺失的历史记录页面
- 统一所有dashboard页面的导航结构
- 创建可复用的导航组件

**架构分析 Architecture Analysis:**
```
/dashboard/               - 策略编辑器 (主仪表盘)
/dashboard/trading/       - 交易面板
/dashboard/advisor/       - 投资顾问
/dashboard/history/       - 历史记录 (新建)
```

**导航结构统一 Navigation Unification:**
| 页面 | 修改前导航项 | 修改后导航项 |
|------|------------|------------|
| /dashboard | 策略编辑器, 投资顾问, 交易面板, 历史记录 | 策略编辑器, 交易面板, 投资顾问, 历史记录 |
| /dashboard/trading | 策略编辑器, 交易面板, 投资顾问 | 策略编辑器, 交易面板, 投资顾问, 历史记录 |
| /dashboard/advisor | 策略生成, 交易面板, 投资顾问 | 策略编辑器, 交易面板, 投资顾问, 历史记录 |

**新增内容 New Files:**
- `src/app/dashboard/history/page.tsx` - 历史记录页面
  - 交易历史: 买卖记录、盈亏、状态
  - 策略历史: 生成策略、回测结果
  - 顾问历史: 咨询记录、分类(三道)
  - 搜索和筛选功能
  - 统计卡片: 总交易数、策略数、顾问咨询数
- `src/components/dashboard/nav-header.tsx` - 统一导航组件
  - 可复用的header组件
  - 自动高亮当前页面
  - 支持双语标签选项

**修改内容 Modified Files:**
- `src/app/dashboard/trading/page.tsx` - 添加历史记录导航链接
- `src/app/dashboard/advisor/page.tsx` - 统一导航项名称和添加历史记录链接

**结果 Result:**
- /dashboard/history 页面正常访问
- 所有dashboard页面导航结构统一
- 构建验证通过 (18个页面全部生成)
- 用户体验改善: 可从任意dashboard页面访问历史记录

---

## 进行中功能 / In Progress

### Phase 2.6: 构建并部署更新

**待完成 Todo:**
- [ ] 部署带历史记录页面和统一导航的新版本到集群

### Phase 3: Agent 智能系统 (CrewAI)

**计划 Plan:**
- [ ] CrewAI + LangGraph 多 Agent 框架
- [ ] 数据采集 Agent (政策/行情/舆情)
- [ ] 分析 Agent (三道六术)
- [ ] 报告生成 Agent
- [ ] 邮件推送服务

### Phase 3: Agent 智能系统

**计划 Plan:**
- [ ] CrewAI + LangGraph 多 Agent 框架
- [ ] 数据采集 Agent (政策/行情/舆情)
- [ ] 分析 Agent (三道六术)
- [ ] 报告生成 Agent
- [ ] 邮件推送服务

### Phase 4: Flutter 多端应用

**计划 Plan:**
- [ ] Flutter 项目初始化
- [ ] 核心功能移植 (登录/首页/对话)
- [ ] K 线图表 Flutter 实现
- [ ] Android/iOS 发布

---

## 部署信息 / Deployment Info

**域名 Domain:** gushen.lurus.cn
**命名空间 Namespace:** ai-qtrd
**节点 Node:** cloud-ubuntu-3-2c2g (worker)
**镜像 Image:** gushen-web:v6
**Service:** ai-qtrd-web:3000

**IngressRoute 路由:**
- `/` → ai-qtrd-web:3000 (前端)
- `/api/strategy` → ai-qtrd-web:3000 (策略 API)
- `/api/advisor` → ai-qtrd-web:3000 (顾问 API)

**环境变量:**
- `NEXT_PUBLIC_API_URL`: https://gushen.lurus.cn
- `LURUS_API_URL`: http://lurus-api.lurus-system.svc.cluster.local:8850
