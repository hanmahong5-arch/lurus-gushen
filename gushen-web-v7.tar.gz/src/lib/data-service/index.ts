/**
 * Unified Data Service Entry Point
 * 统一数据服务入口
 *
 * Provides a single interface for fetching market data with automatic
 * failover between data sources, caching, and observability
 * 提供单一接口获取市场数据，支持数据源自动故障转移、缓存和可观测性
 */

import type {
  StockQuote,
  KLineData,
  IndexQuote,
  CapitalFlow,
  NorthBoundFlow,
  ApiResponse,
  KLineTimeFrame,
  ServiceStats,
  ServiceHealth,
} from "./types";
import { logger } from "./logger";
import * as eastmoney from "./sources/eastmoney";
import * as sina from "./sources/sina";

// Re-export types
// 重新导出类型
export type {
  StockQuote,
  KLineData,
  IndexQuote,
  CapitalFlow,
  NorthBoundFlow,
  ApiResponse,
  KLineTimeFrame,
  ServiceStats,
  ServiceHealth,
};

// =============================================================================
// DATA SOURCE PRIORITY / 数据源优先级
// =============================================================================

/**
 * Data source priority configuration
 * 数据源优先级配置
 */
const DATA_SOURCES = {
  quote: [
    { name: "eastmoney", fn: eastmoney.getStockQuote },
    { name: "sina", fn: sina.getStockQuote },
  ],
  kline: [
    { name: "eastmoney", fn: eastmoney.getKLineData },
    { name: "sina", fn: sina.getKLineData },
  ],
  indices: [
    { name: "eastmoney", fn: eastmoney.getMajorIndices },
    { name: "sina", fn: sina.getMajorIndices },
  ],
  capitalFlow: [{ name: "eastmoney", fn: eastmoney.getCapitalFlow }],
  northBound: [{ name: "eastmoney", fn: eastmoney.getNorthBoundFlow }],
};

// =============================================================================
// UNIFIED API FUNCTIONS / 统一API函数
// =============================================================================

/**
 * Get stock quote with automatic failover
 * 获取股票行情（自动故障转移）
 */
export async function getStockQuote(
  symbol: string
): Promise<ApiResponse<StockQuote>> {
  logger.info("data-service", `Fetching quote for ${symbol}`);

  for (const source of DATA_SOURCES.quote) {
    try {
      const result = await source.fn(symbol);
      if (result.success && result.data) {
        logger.debug("data-service", `Quote fetched from ${source.name}`, {
          symbol,
          cached: result.cached,
        });
        return result;
      }
    } catch (err) {
      logger.warn("data-service", `${source.name} failed for quote ${symbol}`, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  logger.error("data-service", `All sources failed for quote ${symbol}`);
  return {
    success: false,
    data: null,
    error: "All data sources failed",
    source: "data-service",
    cached: false,
    timestamp: Date.now(),
    latency: 0,
  };
}

/**
 * Get K-line data with automatic failover
 * 获取K线数据（自动故障转移）
 */
export async function getKLineData(
  symbol: string,
  timeframe: KLineTimeFrame = "1d",
  limit: number = 200
): Promise<ApiResponse<KLineData[]>> {
  logger.info("data-service", `Fetching K-line for ${symbol}`, {
    timeframe,
    limit,
  });

  for (const source of DATA_SOURCES.kline) {
    try {
      const result = await source.fn(symbol, timeframe, limit);
      if (result.success && result.data && result.data.length > 0) {
        logger.debug("data-service", `K-line fetched from ${source.name}`, {
          symbol,
          timeframe,
          count: result.data.length,
          cached: result.cached,
        });
        return result;
      }
    } catch (err) {
      logger.warn("data-service", `${source.name} failed for K-line ${symbol}`, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  logger.error("data-service", `All sources failed for K-line ${symbol}`);
  return {
    success: false,
    data: null,
    error: "All data sources failed",
    source: "data-service",
    cached: false,
    timestamp: Date.now(),
    latency: 0,
  };
}

/**
 * Get major indices with automatic failover
 * 获取主要指数（自动故障转移）
 */
export async function getMajorIndices(): Promise<ApiResponse<IndexQuote[]>> {
  logger.info("data-service", "Fetching major indices");

  for (const source of DATA_SOURCES.indices) {
    try {
      const result = await source.fn();
      if (result.success && result.data && result.data.length > 0) {
        logger.debug("data-service", `Indices fetched from ${source.name}`, {
          count: result.data.length,
          cached: result.cached,
        });
        return result;
      }
    } catch (err) {
      logger.warn("data-service", `${source.name} failed for indices`, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  logger.error("data-service", "All sources failed for indices");
  return {
    success: false,
    data: null,
    error: "All data sources failed",
    source: "data-service",
    cached: false,
    timestamp: Date.now(),
    latency: 0,
  };
}

/**
 * Get capital flow for a stock
 * 获取股票资金流向
 */
export async function getCapitalFlow(
  symbol: string
): Promise<ApiResponse<CapitalFlow>> {
  logger.info("data-service", `Fetching capital flow for ${symbol}`);

  for (const source of DATA_SOURCES.capitalFlow) {
    try {
      const result = await source.fn(symbol);
      if (result.success && result.data) {
        logger.debug("data-service", `Capital flow fetched from ${source.name}`, {
          symbol,
          cached: result.cached,
        });
        return result;
      }
    } catch (err) {
      logger.warn("data-service", `${source.name} failed for capital flow ${symbol}`, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  logger.error("data-service", `All sources failed for capital flow ${symbol}`);
  return {
    success: false,
    data: null,
    error: "All data sources failed",
    source: "data-service",
    cached: false,
    timestamp: Date.now(),
    latency: 0,
  };
}

/**
 * Get north-bound capital flow
 * 获取北向资金流向
 */
export async function getNorthBoundFlow(): Promise<ApiResponse<NorthBoundFlow>> {
  logger.info("data-service", "Fetching north-bound capital flow");

  for (const source of DATA_SOURCES.northBound) {
    try {
      const result = await source.fn();
      if (result.success && result.data) {
        logger.debug("data-service", `North-bound flow fetched from ${source.name}`, {
          cached: result.cached,
        });
        return result;
      }
    } catch (err) {
      logger.warn("data-service", `${source.name} failed for north-bound flow`, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  logger.error("data-service", "All sources failed for north-bound flow");
  return {
    success: false,
    data: null,
    error: "All data sources failed",
    source: "data-service",
    cached: false,
    timestamp: Date.now(),
    latency: 0,
  };
}

/**
 * Get multiple stock quotes in batch
 * 批量获取多个股票行情
 */
export async function getBatchQuotes(
  symbols: string[]
): Promise<Record<string, ApiResponse<StockQuote>>> {
  logger.info("data-service", `Fetching batch quotes for ${symbols.length} symbols`);

  const results: Record<string, ApiResponse<StockQuote>> = {};

  // Fetch all in parallel
  // 并行获取所有
  const promises = symbols.map(async (symbol) => {
    const result = await getStockQuote(symbol);
    results[symbol] = result;
  });

  await Promise.all(promises);

  const successCount = Object.values(results).filter((r) => r.success).length;
  logger.info("data-service", `Batch quotes completed`, {
    total: symbols.length,
    success: successCount,
    failed: symbols.length - successCount,
  });

  return results;
}

// =============================================================================
// SERVICE MANAGEMENT / 服务管理
// =============================================================================

/**
 * Get service statistics
 * 获取服务统计
 */
export function getServiceStats(): ServiceStats {
  return logger.getStats();
}

/**
 * Get service health status
 * 获取服务健康状态
 */
export function getServiceHealth(): ServiceHealth[] {
  return logger.getAllHealth();
}

/**
 * Get recent logs
 * 获取最近日志
 */
export function getRecentLogs(options?: {
  level?: "debug" | "info" | "warn" | "error";
  source?: string;
  limit?: number;
}) {
  return logger.getLogs(options);
}

/**
 * Get recent metrics
 * 获取最近指标
 */
export function getRecentMetrics(options?: {
  source?: string;
  limit?: number;
}) {
  return logger.getMetrics(options);
}

// =============================================================================
// MOCK DATA FOR DEVELOPMENT / 开发用模拟数据
// =============================================================================

/**
 * Generate mock K-line data for development
 * 生成开发用模拟K线数据
 */
export function generateMockKLineData(
  days: number = 200,
  startPrice: number = 100
): KLineData[] {
  const klines: KLineData[] = [];
  let currentPrice = startPrice;
  const now = new Date();
  now.setHours(0, 0, 0, 0);

  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    const time = Math.floor(date.getTime() / 1000);

    // Generate realistic price movement
    // 生成真实的价格波动
    const volatility = 0.02;
    const trend = Math.sin(i / 30) * 0.001;
    const change = (Math.random() - 0.5) * 2 * volatility + trend;

    const open = currentPrice;
    const close = open * (1 + change);
    const high = Math.max(open, close) * (1 + Math.random() * volatility * 0.5);
    const low = Math.min(open, close) * (1 - Math.random() * volatility * 0.5);
    const volume = Math.round(1000000 + Math.random() * 500000);

    klines.push({
      time,
      open: parseFloat(open.toFixed(2)),
      high: parseFloat(high.toFixed(2)),
      low: parseFloat(low.toFixed(2)),
      close: parseFloat(close.toFixed(2)),
      volume,
    });

    currentPrice = close;
  }

  return klines;
}

/**
 * Generate mock quote data for development
 * 生成开发用模拟行情数据
 */
export function generateMockQuote(symbol: string, name: string): StockQuote {
  const basePrice = 50 + Math.random() * 200;
  const change = (Math.random() - 0.5) * 10;
  const changePercent = (change / basePrice) * 100;

  return {
    symbol,
    name,
    price: parseFloat(basePrice.toFixed(2)),
    change: parseFloat(change.toFixed(2)),
    changePercent: parseFloat(changePercent.toFixed(2)),
    open: parseFloat((basePrice - change * 0.5).toFixed(2)),
    high: parseFloat((basePrice + Math.abs(change) * 0.5).toFixed(2)),
    low: parseFloat((basePrice - Math.abs(change) * 0.5).toFixed(2)),
    prevClose: parseFloat((basePrice - change).toFixed(2)),
    volume: Math.round(10000000 + Math.random() * 50000000),
    amount: Math.round(500000000 + Math.random() * 2000000000),
    turnoverRate: parseFloat((Math.random() * 5).toFixed(2)),
    pe: parseFloat((10 + Math.random() * 40).toFixed(2)),
    pb: parseFloat((1 + Math.random() * 5).toFixed(2)),
    marketCap: Math.round(10000000000 + Math.random() * 100000000000),
    timestamp: Date.now(),
  };
}

/**
 * Generate mock index data for development
 * 生成开发用模拟指数数据
 */
export function generateMockIndices(): IndexQuote[] {
  const indices = [
    { symbol: "000001", name: "上证指数", base: 3200 },
    { symbol: "399001", name: "深证成指", base: 10500 },
    { symbol: "399006", name: "创业板指", base: 2100 },
    { symbol: "000300", name: "沪深300", base: 3800 },
    { symbol: "000016", name: "上证50", base: 2600 },
  ];

  return indices.map((idx) => {
    const change = (Math.random() - 0.5) * idx.base * 0.02;
    const changePercent = (change / idx.base) * 100;

    return {
      symbol: idx.symbol,
      name: idx.name,
      price: parseFloat((idx.base + change).toFixed(2)),
      change: parseFloat(change.toFixed(2)),
      changePercent: parseFloat(changePercent.toFixed(2)),
      volume: Math.round(100000000 + Math.random() * 500000000),
      amount: Math.round(100000000000 + Math.random() * 500000000000),
      timestamp: Date.now(),
    };
  });
}
