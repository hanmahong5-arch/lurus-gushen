/**
 * Market Indices API Route
 * 市场指数API路由
 *
 * GET /api/market/indices
 */

import { NextResponse } from "next/server";
import { getMajorIndices, generateMockIndices } from "@/lib/data-service";

// Environment flag for using mock data
// 使用模拟数据的环境标志
const USE_MOCK = process.env.USE_MOCK_DATA === "true";

export async function GET() {
  try {
    if (USE_MOCK) {
      const mockIndices = generateMockIndices();
      return NextResponse.json({
        success: true,
        data: mockIndices,
        source: "mock",
        cached: false,
        timestamp: Date.now(),
        latency: 0,
      });
    }

    const result = await getMajorIndices();
    return NextResponse.json(result);
  } catch (err) {
    console.error("Indices API error:", err);
    return NextResponse.json(
      {
        success: false,
        error: err instanceof Error ? err.message : "Internal server error",
      },
      { status: 500 }
    );
  }
}
