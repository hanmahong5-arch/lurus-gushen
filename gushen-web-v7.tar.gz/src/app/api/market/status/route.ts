/**
 * Data Service Status API Route
 * 数据服务状态API路由
 *
 * GET /api/market/status - Get service health and statistics
 */

import { NextResponse } from "next/server";
import { getServiceStats, getServiceHealth, getRecentLogs, getRecentMetrics } from "@/lib/data-service";

export async function GET() {
  try {
    const stats = getServiceStats();
    const health = getServiceHealth();
    const recentLogs = getRecentLogs({ limit: 20, level: "info" });
    const recentMetrics = getRecentMetrics({ limit: 20 });

    return NextResponse.json({
      success: true,
      data: {
        stats,
        health,
        recentLogs,
        recentMetrics,
      },
      timestamp: Date.now(),
    });
  } catch (err) {
    console.error("Status API error:", err);
    return NextResponse.json(
      {
        success: false,
        error: err instanceof Error ? err.message : "Internal server error",
      },
      { status: 500 }
    );
  }
}
